# React Practical Solutions

Each question is implemented in its own React component file.

- `src/components/Counter.jsx` — Q1 Counter
- `src/components/TodoList.jsx` — Q2 Todo List
- `src/components/LoginToggle.jsx` — Q3 Login Toggle
- `src/components/LiveSearchFilter.jsx` — Q4 Live Search Filter
- `src/components/Stopwatch.jsx` — Q5 Stopwatch
- `src/App.jsx` imports and displays all five components.
- `src/styles.css` contains shared styling.

## Run in VS Code

Open this folder in VS Code, then run in Terminal:

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal, usually `http://localhost:5173`.

To check a production build:

```bash
npm run build
```

## Upload to GitHub

Create a new repository on GitHub, then run these commands from this folder:

```bash
git init
git add .
git commit -m "Add React practical solutions"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/react-practical-solutions.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Do not upload `node_modules`; it is recreated with `npm install`.
