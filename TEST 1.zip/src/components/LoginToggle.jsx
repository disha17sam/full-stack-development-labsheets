import { useState } from "react";

export default function LoginToggle() {
  const [loggedIn, setLoggedIn] = useState(false);

  return (
    <section className="task-card">
      <h2>Q3. Login Toggle</h2>
      {loggedIn ? (
        <div className="welcome-panel">
          <p className="welcome">Welcome back!</p>
          <p className="muted">You are currently logged in.</p>
          <button className="secondary" onClick={() => setLoggedIn(false)}>Logout</button>
        </div>
      ) : (
        <>
          <p className="muted">You are currently logged out.</p>
          <button onClick={() => setLoggedIn(true)}>Login</button>
        </>
      )}
    </section>
  );
}
