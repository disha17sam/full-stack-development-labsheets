import { useState } from "react";

export default function Counter() {
  const [count, setCount] = useState(0);

  return (
    <section className="task-card">
      <h2>Q1. Counter</h2>
      <p className="muted">Increment, decrement, and reset the running count.</p>
      <div className="count-display" aria-live="polite">{count}</div>
      <div className="button-row">
        <button onClick={() => setCount((value) => value + 1)}>Increment +</button>
        <button className="secondary" onClick={() => setCount((value) => value - 1)} disabled={count === 0}>Decrement −</button>
        <button className="light" onClick={() => setCount(0)}>Reset</button>
      </div>
      <small>Decrement is disabled when the count reaches 0.</small>
    </section>
  );
}
