import { useState } from "react";

const names = [
  "Aarav Sharma", "Diya Verma", "Ishaan Gupta", "Ananya Singh",
  "Rohan Mehta", "Priya Das", "Kabir Khan", "Meera Joshi",
  "Arjun Patel", "Sara Ali"
];

export default function LiveSearchFilter() {
  const [query, setQuery] = useState("");
  const filteredNames = names.filter((name) =>
    name.toLowerCase().includes(query.trim().toLowerCase())
  );

  return (
    <section className="task-card">
      <h2>Q4. Live Search Filter</h2>
      <p className="muted">Search the hardcoded list. Results update as you type.</p>
      <input className="full-input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search names..." aria-label="Search names" />
      {filteredNames.length > 0 ? (
        <ul className="name-list">
          {filteredNames.map((name) => <li key={name}>{name}</li>)}
        </ul>
      ) : (
        <p className="no-results" role="status">No results found</p>
      )}
    </section>
  );
}
