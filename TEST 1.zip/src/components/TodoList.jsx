import { useState } from "react";

export default function TodoList() {
  const [input, setInput] = useState("");
  const [items, setItems] = useState([]);
  const [nextId, setNextId] = useState(1);

  function addItem(event) {
    event.preventDefault();
    const text = input.trim();
    if (!text) return;
    setItems((current) => [...current, { id: nextId, text }]);
    setNextId((id) => id + 1);
    setInput("");
  }

  function deleteItem(id) {
    setItems((current) => current.filter((item) => item.id !== id));
  }

  return (
    <section className="task-card">
      <h2>Q2. Todo List</h2>
      <p className="muted">Add tasks and delete individual items.</p>
      <form className="input-row" onSubmit={addItem}>
        <input value={input} onChange={(event) => setInput(event.target.value)} placeholder="Enter a task..." aria-label="New task" />
        <button type="submit">Add Item</button>
      </form>
      {items.length === 0 ? <p className="empty-state">No tasks yet. Add one above.</p> : (
        <ul className="todo-list">
          {items.map((item) => (
            <li key={item.id}>
              <span>{item.text}</span>
              <button className="danger" onClick={() => deleteItem(item.id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
