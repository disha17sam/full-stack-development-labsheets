import { useEffect, useState } from "react";

export default function Stopwatch() {
  const [elapsed, setElapsed] = useState(0);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    if (!running) return undefined;
    const startedAt = Date.now() - elapsed * 1000;
    const timerId = window.setInterval(() => {
      setElapsed(Math.floor((Date.now() - startedAt) / 1000));
    }, 200);
    return () => window.clearInterval(timerId);
  }, [running]);

  function reset() {
    setRunning(false);
    setElapsed(0);
  }

  const hours = String(Math.floor(elapsed / 3600)).padStart(2, "0");
  const minutes = String(Math.floor((elapsed % 3600) / 60)).padStart(2, "0");
  const seconds = String(elapsed % 60).padStart(2, "0");

  return (
    <section className="task-card">
      <h2>Q5. Stopwatch</h2>
      <p className="muted">Start, pause/resume, and reset elapsed time.</p>
      <div className="stopwatch-display" aria-live="polite">{hours}:{minutes}:{seconds}</div>
      <div className="button-row">
        <button onClick={() => setRunning(true)} disabled={running}>Start</button>
        <button className="secondary" onClick={() => setRunning(false)} disabled={!running}>Pause</button>
        <button className="light" onClick={reset}>Reset</button>
      </div>
    </section>
  );
}
