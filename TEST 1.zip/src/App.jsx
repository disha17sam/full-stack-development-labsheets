import Counter from "./components/Counter.jsx";
import TodoList from "./components/TodoList.jsx";
import LoginToggle from "./components/LoginToggle.jsx";
import LiveSearchFilter from "./components/LiveSearchFilter.jsx";
import Stopwatch from "./components/Stopwatch.jsx";

export default function App() {
  return (
    <main className="page">
      <header className="hero">
        <p className="eyebrow">REACT.JS PRACTICAL</p>
        <h1>React Practical Solutions</h1>
        <p>Five interactive components, each in its own file.</p>
      </header>
      <div className="tasks-grid">
        <Counter />
        <TodoList />
        <LoginToggle />
        <LiveSearchFilter />
        <Stopwatch />
      </div>
      <footer>Built with React Hooks: useState and useEffect.</footer>
    </main>
  );
}
